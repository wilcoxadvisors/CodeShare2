module.exports = {
  content: [
    './src/**/*.{js,jsx}',
    './src/pages/**/*.{js,jsx}', // Ensure this is included
  ],
  theme: { extend: {} },
  plugins: [],
};
